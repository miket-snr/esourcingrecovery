export const environment = {
  production: true,
  apiUrl: 'http://localhost:4000',
  apikey: 'GENAPP',
  BASE_API: 'https://io.bidvestfm.co.za/BIDVESTFM_API_AUTH',
  BASE_API2: 'https://io.bidvestfm.co.za/BIDVESTFM_API_AUTH',
  BASE_POST: 'https://io.bidvestfm.co.za/BIDVESTFM_API_GEN/genpost'
};
