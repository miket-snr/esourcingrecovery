export class RFQItem {
  SUBMI: string;
  RFQNO: string;
  ITEMNO: number;
  CUTOFF: string;
  VENDORNO: string;
  VENDOR: string;
  MATERIAL: string;
  UNIT: string;
  DELIVERYDATE: string;
  MTEXT: string;
  QUANTITY: number;
  PRICE: number;
}
