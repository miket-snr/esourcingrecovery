export class RFQHeader {
  SUBMI: string;
  RFQNO: string;
  CUTOFF: string;
  VENDORNO: string;
  VENDOR: string;
}
