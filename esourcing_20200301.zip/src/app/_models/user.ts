﻿export class User {
  username: string;
  firstName: string;
  lastName: string;
  role: string;
  cellno: string;
  sundry: string;
}

export class Vendor {
  vendorname: string;
  vendor: string;
}
