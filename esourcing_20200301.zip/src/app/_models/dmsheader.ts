export class DMSHeader {
  id: number;
  APIKEY: string;
  DOCNO: string;
  COUNTER: string;
  FILESIZE: string;
  MIMETYPE: string;
  ORIGINALNAME: string;
}
