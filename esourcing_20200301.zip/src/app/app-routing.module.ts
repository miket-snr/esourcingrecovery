import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { ImgtopdfComponent } from './_helpers/imgtopdf/imgtopdf.component';
import { AuthGuard } from './_helpers';
import { EsourcingComponent } from './esourcing/esourcing.component';

const appRoutes: Routes = [
  { path: '', component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'esourcing', component: EsourcingComponent, canActivate: [AuthGuard] },
  { path: 'topdf', component: ImgtopdfComponent, canActivate: [AuthGuard] },
  { path: 'auth', loadChildren: './auth/auth.module#AuthModule' },

  // otherwise redirect to home
  { path: '**', redirectTo: '' }
  // Here we load the module only when
  // the user access to login or register pages
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
