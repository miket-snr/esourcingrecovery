# angular-8- Bidvestfm - RFQ Portal

RFQs are read from User-linked Vendor
Only newest are read in
